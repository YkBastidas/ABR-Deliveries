const express = require('express');
const path = require('path');
const bodyParser = require ('body-parser');

const aplicacion =express();

aplicacion.set('port', process.env.PORT || 3000);
aplicacion.set('vistas',path.join(__dirname),'../aplicacion/vistas')
aplicacion.use(bodyParser.urlencoded({extended: false}));

module.exports = aplicacion;