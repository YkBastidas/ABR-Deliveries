const aplicacion = require('./configuracion/servidor')

require('./aplicacion/rutas/prueba')(aplicacion);

//niciar servidor
aplicacion.listen(app.get('port'), () =>{
    console.log('server on port: ',aplicacion.get('port'))

});