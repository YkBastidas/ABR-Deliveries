module.exports = aplicacion =>{
    aplicacion.get('/',(req,res)=>{
        res.send('hello world')
    });
}